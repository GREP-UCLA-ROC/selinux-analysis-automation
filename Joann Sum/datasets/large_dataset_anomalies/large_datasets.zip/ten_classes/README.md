Violation classes:
0: No anomalies
1: Separation of Duty (SoD) violation
2: Overly permissive access
3: Improper privilege assignment
4: Critical system file modification
5: Contradictory rules
6: Missing necessary rules
7: Incorrect type usage
8: Domain transition issues
9: Mislabeled files or processes
10: Unauthorized network access